from django.shortcuts import render,redirect
from .models import Product
from .models import Category
from .models import Customer
from .models import Order
# from django.utils.decorators import method_decorator
from django .http import HttpResponse
from django.views import View
from django.contrib.auth.hashers import make_password , check_password
# Create your views here.


class Index(View):
    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1
        request.session['cart'] = cart
        print('cart',request.session['cart'])

        return redirect('homepage')
    
    def get(self, request):
            products = None
            # request.session.get('cart').clear()
            categories = Category.get_all_categories();
            categoryID = request.GET.get('category')
            if categoryID:
                products = Product.get_all_products_by_categoryid(categoryID);
            else:
                products = Product.get_all_products();
            data={}
            data['products']=products
            data['categories']=categories
            return render (request, 'index.html', data)

class Signup(View):
    def get(self, request):
         return render (request, 'signup.html')
    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        

        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }

        error_message = None
        customer = Customer(first_name = first_name , last_name = last_name  , phone = phone , email = email , password = password)
        error_message = self.validateCustomer(customer)
        
        if not error_message:
            print(first_name, last_name, phone, email, password)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data ={
                'error':error_message,
                'values':value
                }
            
            return render(request, "signup.html",data )
        
    def validateCustomer(self, customer):
        error_message = None;
        if(not customer.first_name):
            error_message = "First name is required!!"
        elif len(customer.first_name) < 4:
            error_message = "First name must be 4 character long or more"
        elif  not customer.last_name:
            error_message = "Last name is required!!!"
        elif  len(customer.last_name)<4:
            error_message = "Last name must be 4 character long or more"
        elif  not customer.phone:
            error_message = "Phone number required"
        elif  len(customer.phone)<10:
            error_message = "Phone number must be 10 character long"
        elif len(customer.password)<6:
            error_message = "Password must be 6 character long"
        elif len(customer.email)<5:
            error_message = "Email must be 5 character long"
        elif customer.isExist():
            error_message = "Email already exist"

        return error_message
    

class Login(View):
    def get(self, request):
        return render(request, 'login.html')
    
    def post(self, request):
        email = request.POST.get('email')  
        password = request.POST.get('password')  
        error_message = None
        if not email or not password:
            error_message = "Email and password are required."
            return render(request, 'login.html', {'error': error_message})
        customer = Customer.get_customer_by_email(email)

        if customer:
            # Check the password
            if check_password(password, customer.password):
                request.session['customer'] = customer.id
                request.session['email'] = customer.email
                return redirect('homepage')
            else:
                error_message = "Email or password is invalid"
        else:
            error_message = "Email does not exist"
        return render(request, 'login.html', {'error': error_message})
    
def logout(request):
    request.session.clear()
    return redirect('login')

class Cart(View):
    def get(self, request):
        ids = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(ids)
        return render(request, 'cart.html',{'products':products})
    
class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address, phone, customer, cart, products)
        for product in products:
            order = Order(customer = Customer(id=customer), product = product, price = product.price, address = address, phone = phone, quantity = cart.get(str(product.id)))
            order.save()
        request.session['cart']={}
        return redirect ('cart')
    
class OrderView(View):
    # @method_decorator(auth_middleware)
    def get(self, request):
        customer_id = request.session.get('customer')
        if not customer_id:
            return render(request, 'order.html', {'orders': []})
        orders = Order.get_orders_by_customer(customer_id)
        print(orders[5].status)
        return render(request, 'order.html', {'orders': orders})